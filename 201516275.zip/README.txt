#######################################
#                                     #
#           IML HACKATHON             #
#                                     #
#######################################


############### Scripts ###############
regression.py
This file include 'predict' function as API demands


regression_class.py
- contain preproccing data
- all figures
- define the model
- save the model object as binary file

############### Binary files ###############
our_model_revenue.bi - our model object
pop_words.bi - list of most popular words in overviews
